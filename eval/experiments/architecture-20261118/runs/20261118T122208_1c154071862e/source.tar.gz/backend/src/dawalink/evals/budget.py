"""Durable experiment-wide accounting. All amounts are integer micro-dollars.

Reservations survive crashes and ambiguous provider failures; never silently release
unknown charges. This intentionally stops early rather than risking the $25 ceiling.
"""

import os
import sqlite3
import uuid
from pathlib import Path
from typing import Any

from dawalink.agent.llm.base import LLMRejected, ModelReply, Prompt
from dawalink.agent.llm.claude import ClaudeModel

CAPS = {
    "baseline": 4_000_000,
    "screening": 6_000_000,
    "expanded": 10_000_000,
    "heldout": 3_000_000,
    "retries": 2_000_000,
}
TOTAL = 25_000_000
# Full 1M input at 5m-cache-write long-context rate, plus 8000 output tokens.
# https://platform.claude.com/docs/en/models/haiku-5-5/overview (2026-11-18)
HAIKU_RESERVATION = 645_000


class Ledger:
    def __init__(self, path: Path) -> None:
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS calls (
                id TEXT PRIMARY KEY, run TEXT NOT NULL, stage TEXT NOT NULL,
                held INTEGER NOT NULL, actual INTEGER, status TEXT NOT NULL,
                created TEXT DEFAULT CURRENT_TIMESTAMP)""")

    def connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path, timeout=30)

    def reserve(self, run: str, stage: str, amount: int = HAIKU_RESERVATION) -> str:
        if stage not in CAPS or amount <= 0:
            raise ValueError("invalid stage or reservation")
        call = uuid.uuid4().hex
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            total, local = db.execute(
                "SELECT COALESCE(SUM(held),0), COALESCE(SUM(CASE WHEN stage=? "
                "THEN held ELSE 0 END),0) FROM calls",
                (stage,),
            ).fetchone()
            if total + amount > TOTAL or local + amount > CAPS[stage]:
                raise LLMRejected("evaluation budget reservation refused")
            db.execute(
                "INSERT INTO calls(id,run,stage,held,status) VALUES(?,?,?,?,?)",
                (call, run, stage, amount, "reserved"),
            )
        return call

    def settle(self, call: str, actual: int) -> None:
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT held,status FROM calls WHERE id=?", (call,)).fetchone()
            if not row or row[1] != "reserved" or not 0 <= actual <= row[0]:
                raise ValueError("invalid settlement; reservation retained")
            db.execute(
                "UPDATE calls SET held=?,actual=?,status='settled' WHERE id=?",
                (actual, actual, call),
            )

    def uncertain(self, call: str) -> None:
        with self.connect() as db:
            db.execute(
                "UPDATE calls SET status='uncertain' WHERE id=? AND status='reserved'", (call,)
            )

    def totals(self) -> dict[str, int]:
        with self.connect() as db:
            row = db.execute(
                "SELECT COALESCE(SUM(actual),0), COALESCE(SUM(held),0), COUNT(*) FROM calls"
            ).fetchone()
        return {"known_spend_microusd": row[0], "committed_microusd": row[1], "calls": row[2]}


class EvaluationModel(ClaudeModel):
    """Same agent/model request; budget wrapper used only by evaluation runners."""

    def __init__(self, **kwargs: Any) -> None:
        if kwargs.get("model") != "claude-haiku-5-5":
            raise ValueError("Only the frozen Haiku model has verified evaluation pricing")
        path, run = os.environ.get("EVAL_LEDGER"), os.environ.get("EVAL_RUN_ID")
        if not path or not run:
            raise ValueError("Paid evaluations require EVAL_LEDGER and EVAL_RUN_ID")
        self.ledger = Ledger(Path(path))
        self.run_id = run
        self.stage = os.environ.get("EVAL_STAGE", "baseline")
        super().__init__(**kwargs)

    def complete(self, prompt: Prompt, *, timeout_s: float) -> ModelReply:
        call = self.ledger.reserve(self.run_id, self.stage)
        try:
            reply = super().complete(prompt, timeout_s=timeout_s)
            used = reply.usage
            # Round up; long-context threshold applies to all input including cached tokens.
            factor = 5 if used.input_tokens > 100_000 else 1
            plain = max(0, used.input_tokens - used.cached_tokens - used.cache_write_tokens)
            from decimal import ROUND_CEILING, Decimal

            amount = (
                Decimal(plain) * Decimal("0.10")
                + Decimal(used.output_tokens) * Decimal("0.50")
                + Decimal(used.cached_tokens) * Decimal("0.01")
                + Decimal(used.cache_write_tokens) * Decimal("0.125")
            ) * factor
            self.ledger.settle(call, int(amount.to_integral_value(rounding=ROUND_CEILING)))
            return reply
        except BaseException:
            self.ledger.uncertain(call)
            raise
